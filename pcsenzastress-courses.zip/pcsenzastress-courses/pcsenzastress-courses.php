<?php
/*
Plugin Name: Pcsenzastress Courses
Plugin URI: http://www.VibeThemes.com
Description: Plugin to show only free courses to unregistered users and all courses to registered users.
Version: 1.0
Author: Diana
Author URI: http://www.VibeThemes.com
Text Domain: wplms-pc
Domain Path: /languages/
*/

/**
 * Show courses to students
 *
 * @author      VibeThemes
 * @category    Admin
 * @package     Initialization
 * @version     1.0
 */

if ( !defined( 'ABSPATH' ) ) exit;

class pcsenzastress_courses{

    public static $instance;
    
    public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new pcsenzastress_courses();

        return self::$instance;
    }

    private function __construct(){

    //add_filter('wplms_course_directory_list',array($this,'pcsenzastress_courses'));
    //add_filter('bp_course_wplms_filters',array($this,'pcsenzastress_courses'));
    //add_action('bp_directory_course_item',array($this,'pcsenzastress_courses'));
    add_filter('bp_course_single_item',array($this,'pcsenzastress_courses'), 9999);

    	}

 
    function pcsenzastress_courses($post){
        global $post, $wpdb;
        $id = $post->ID;
        $excluded_courses=get_post_meta($id,'vibe_course_free',true);

        if(!is_user_logged_in() && $excluded_courses == 'S'){

          $post_meta = get_post_meta($id);
          $filter = apply_filters('bp_course_single_item_view',0);
          if($filter){
          return;
          }
?>
          <li class="<?php echo $course_classes; ?>" itemscope itemtype="http://data-vocabulary.org/Review-aggregate">
          <div class="item-avatar" itemprop="photo">
          <?php bp_course_avatar(); ?>
          </div>

          <div class="item">
          <div class="item-title"  itemprop="itemreviewed"><?php bp_course_title(); if(get_post_status() != 'publish'){echo '<i> ( '.get_post_status().' ) </i>';} ?></div>
          <div class="item-meta"><?php bp_course_meta(); ?></div>
          <div class="item-desc"><?php bp_course_desc(); ?></div>
          <div class="item-credits">
          <?php bp_course_credits(); ?>
          </div>
          <div class="item-instructor">
          <?php bp_course_instructor(); ?>
          </div>
          <div class="item-action"><?php bp_course_action() ?></div>
          </div>
          </li>
          <div class="clear"></div>
          <style>
          .item-list li div.row{display:none !important;}
          </style>
          <?php
          //return $post_meta;
          // return 1;
          do_action( 'bp_directory_course_item' );

        }

         
        //$post = array();
        //echo $id;
        //unset($post->ID);
        //unset($post->post_title);
        //unset($post);
        //return $post;

//print_r($post_meta);          



/*
          global $post;
          $id = $post->ID;

          $free_course = get_post_meta($id,'vibe_course_free',true);
          if(!is_user_logged_in() && $free_course =='S'){
            echo '<div class="course_block">'; 
            return the_title();
            echo '</div>';
            return 1;
          }
*/

   
   } // Function close  
  

}

pcsenzastress_courses::init();